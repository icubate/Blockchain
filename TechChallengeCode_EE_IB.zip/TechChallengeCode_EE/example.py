import socket               

s = socket.socket()         
port = 80
s.connect(('127.0.0.1', port))  #local host for testing, private address found by ipconfig
print(s.recv(1024).decode())
f = open("pdftest.pdf", "rb")
l = f.read(1024)
print("Sending data...")
while (l):
    s.send(l)
    l = f.read(1024)
f.close()
print("Done Sending!")
print("Logging off...")
s.shutdown(socket.SHUT_WR)
print(s.recv(1024).decode())
s.close()
