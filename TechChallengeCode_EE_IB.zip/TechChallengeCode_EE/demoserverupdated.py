import socket
import hashlib as hasher
import datetime
import time
import sys
from blockchain import Block

#Initial information to add to list, numbers represent people in the case of the index and physicians
firstBlock = Block(float(40), datetime.datetime.now(), [45, 12], "patientdata_2.pdf", 0)
blockList = [firstBlock]

#Other initial values
checkIndex, oldHash, clock = [0, 0, 0]
prevDoctors = list()
medData = open("patientdata_" + str(checkIndex) + ".pdf", 'wb')

#Create Socket
s = socket.socket()         
print("Socket successfully created!")
port = 80                
s.bind(('localhost', port))        
print("Socket bound to Port %s" % port)
s.listen(5)     
print("Listening...")
while True:
    c, addr = s.accept()     
    print('Got connection from', addr)

#Verify if new genesis block is a new patient
    print("where")
    val = c.recv(8).decode()
    print("looking")
    checkIndex = int(val)
    print("CheckINDEX")
    #checkIndex = int.from_bytes(c.recv(1024),'@')
    if checkIndex in blockList:
        c.send("Regular Patient".encode())
    else:
        c.send("New Patient!".encode())
        newPatient = Block(checkIndex, clock, prevDoctors, medData, oldHash)
        clock = c.recv(1024).decode()
        prevDoctors.append(c.recv(1024).decode())
        log = c.recv(1024)
        while log:
            print("here")
            medData.write(log)
            log = c.recv(1024)

#Initialize values for updating lists
    sendID = 0
    sendTime = 0
    sendMD = []
    secondBlock = Block(float(75), datetime.datetime.now(), [12], "patientdata_1.pdf", 0)
    blockList.append(secondBlock)
    checkUpdate = c.recv(1024).decode()

#If a more recent entry has arrived or there is a missing entry in the server's or client's list, update
    while True:
        for things in blockList:
            thisOne = things.timestamp
            if things.timestamp > checkUpdate or clientKey not in things.index:
                num = blockList.index(thisOne)
                sendID = blockList[num].index
                sendTime = blockList[num].timestamp
                sendFile = blockList[num].data
                sendMD = blockList[num].physicians

                sendFile = blockList[num].data.read(1024)
                while sendFile:
                    c.send(sendFile)
                    sendFile = blockList[num].data.read(1024)
                sendFile.close()
                print("Done sending records")
                c.shutdown(socket.SHUT_WR)

                check = 3
                while check > 0:
                        switch = str(c.recv(1024).decode())
                        if switch == str("Who was the patient?"):
                            c.send(bytes(sendID))
                            print("Patient info sent")
                            check += -1
                            switch = str(c.recv(1024).decode())
                        if switch == str("What time?"):
                            c.send(sendTime.encode())
                            print("Time sent")
                            check += -1
                            switch = str(c.recv(1024).decode())
                        if switch == str("Who were the doctors?"):
                            for doctors in sendMD:
                                c.send(sendMD[doctors].encode)
                                time.sleep(0.1)
                            print("MD info sent")
                            check += -1
                print("Update sent")
                break

#If no updates yet, keep running loop until there is or the connection ends
            else:
                checkUpdate = c.recv(1024).decode()

# Create report and send as email
#    sender = 'eae4461@gmail.com'
#    receivers = ['eae4461@gmail.com']

#    if data == '':
#        msg = 'The patient file has been updated at' + time.strftime(“ % c”)
#    else:
#        msg = 'Error: Mixup in patient data' + time.strftime(“ % c”)

#    mtpObj = smtplib.SMTP('mailhost.gmail.com', 25)
 #   smtpObj.sendmail(sender, receivers, msg)
#    smtpObj.quit()