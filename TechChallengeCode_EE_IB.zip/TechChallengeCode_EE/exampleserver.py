import socket               

s = socket.socket()         
print("Socket successfully created!")
port = 80                
s.bind(('127.0.0.1', port))                     #local host for testing, private address found by ipconfig
print("Socket bound to Port %s" %(port))
s.listen(5)     
print("Listening...")
while True:
    c, addr = s.accept()     
    print('Acquired connection from', addr)
    c.send(('Welcome!').encode())
    i = 3
    f = open('patientdata_' + str(i) +".pdf",'wb')   # create new file to transfer sent file's info into
    print("Creating new patient data document...")
    i=i+1
    l = c.recv(1024)
    print("Receiving data...")
    while (l):
        f.write(l)
        l = c.recv(1024)
    f.close()
    print("Data transmission complete!")
    c.send(("Thank you for connecting.").encode())
    print(c.recv(1024).decode())
    c.close()