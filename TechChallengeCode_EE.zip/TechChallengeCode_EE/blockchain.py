import hashlib as hasher
import datetime
import time


class Block:

  def __init__(self, index, timestamp, physicians, data, previous_hash):
    self.index = index
    self.physicians = list()
    self.timestamp = timestamp
    self.data = data
    self.previous_hash = previous_hash
    self.hash = self.hashBlock()
  
  def hashBlock(self):
    # hashString = str(self.index) + str(self.timestamp) + str(self.data) + str(self.previous_hash)
    hash_object = hasher.sha1(b'str(self.index) + str(self.timestamp) + str(self.data) + str(self.previous_hash)')
    return hash_object.hexdigest()






    