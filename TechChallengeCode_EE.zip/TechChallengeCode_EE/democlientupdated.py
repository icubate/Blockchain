import socket
import hashlib as hasher
import datetime
import time
import sys
from blockchain import Block               

seriesIndex = 75                                                         # Patient ID is blank (need value from scanner)
professional = 12                                                        # Doctor ID is blank (need value from scanner)
doctors = list()
doctors.append(professional)
seriesData = open('patientdata_' + str(seriesIndex) + ".pdf", 'wb')      # Create blank data file
punchClock = datetime.datetime.now()                                    # Time of check-in
recordTime = punchClock
currentBlock = Block(seriesIndex, punchClock, doctors, seriesData, 0)      # Create genesis block
blockList = [currentBlock]                                              # Create list of patient information for later
print("Genesis block has been created")

s = socket.socket()                 # Connect to server
port = 80
s.connect(('localhost', port))

print("je")
val = str(seriesIndex)
s.send(val.encode())
print("te")
#s.send(bytes(seriesIndex, '@')) # Now that you're connected, check to see if anyone else has seen him
indexString = s.recv(1024).decode()   # Wait for response...
print(indexString)
if indexString == "New Patient!":
    t = recordTime.read(1024)
    print("Sending Time")
    while t:
        s.send(t)
        t = recordTime.read(1024)             # Begin loops of sending patient data to server
    
    p = professional.read(1024)
    print("Sending Physician")
    while p:
        s.send(p)
        p = professional.read(1024)

    f = open('newdata_' + str(seriesIndex) + ".pdf", 'rb')
    n = f.read(1024)
    print("Sending Data")
    while n:
        s.send(n)
        n = f.read(1024)
    f.close()  

postUpdate = 0
j = open("blankdata.pdf", 'wb')
msg = datetime.datetime.now()
print("here")
while True:
    s.send(msg.encode())
    time.sleep(2)                   # Ask for updates
    log = s.recv(1024)                # Wait for response
    while log:                      # When there is an update...
        postUpdate = 1              # ...change bit for updating list later
        j.write(log)         # Begin updating data file 1024 bytes at a time
        log = s.recv(1024)
    if postUpdate == 1:             # After receiving all of the data...
        print("Update!")
        j.close()                   # Close data file   
        print("Finished Receiving!")
        newestPatientData = newestPatientData = open('patientdata_' + str(seriesIndex) + ".pdf", 'wb')

        who = str("Who was the patient?")
        s.send(who).encode()
        w = int.from_bytes(s.recv(1024), '@')
        print(w)
        patientIndex = w
        if w in blockList[:].index:             # If patient was in blockList, update the entry with new information
            num = blockList.index.index(w)
            blockList[num].previous_hash = blockList[num].hash
            
            ques = str("What time?")
            time.sleep(1)
            s.send(ques).encode()
            tick = s.recv(1024).decode()
            print(tick)
            blockList[num].timestamp = tick
            newTimestamp = tick

            print("Time to copy over data")
            copy = open("blankdata.pdf", 'wb')
            newestPatientData = open('patientdata_' + str(seriesIndex) + ".pdf", 'wb')
            dummy = copy.read(1024)
            while dummy:
                dummy = copy.read(1024)
            print("Done copying!")
            copy.close()
            newestPatientData.close()
            blockList[num].data = newestPatientData

            blockList[num].hash = blockList[num].hashBlock()

            ques2 = str("Who were the doctors?")
            s.send(ques2).encode()
            q = s.recv(1024).decode()
            start = 0
            while q:
                blockList[num].physicians[start] = q
                newPatientBlock.physicians[start] = q
                print(q)
                q = str(s.recv(1024).decode())
            postUpdate = 0
        else:                                               # If the patient was not in blockList, create a new entry
            newTimestamp = 0
            newDoctors = []

            oldHash = 0
            # newPatientBlock = Block(patientIndex, newTimestamp, newDoctors, newestPatientData, oldHash)

            ques = str("What time?")
            s.send(ques).encode()
            tick = s.recv(1024).decode()
            print(tick)
            newTimestamp = tick

            print("Time to copy over data")
            copy = open("blankdata.pdf", 'wb')
            dummy = copy.read(1024)
            while dummy:
                newestPatientData.write(dummy)
                dummy = copy.read(1024)
            print("Done copying!")
            copy.close()
            newestPatientData.close()

            newPatientBlock.hash = newPatientBlock.hashBlock

            ques2 = str("Who were the doctors?")
            s.send(ques2).encode()
            q = s.recv(1024).decode()
            start = 0
            while q:
                newPatientBlock.physicians[start] = q
                print(q)
                q = str(s.recv(1024).decode())
            
            blockList.append(newPatientBlock)
            postUpdate = 0
